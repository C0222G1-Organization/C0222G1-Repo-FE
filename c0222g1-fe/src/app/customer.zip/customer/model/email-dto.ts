export interface EmailDto {
  id?: number;
  email?: string;
}
