export interface PhoneDto {
  id?: number;
  phone?: string;
}
