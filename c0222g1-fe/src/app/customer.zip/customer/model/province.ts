export interface Province {
  id?: number;
  name?: string;
}
