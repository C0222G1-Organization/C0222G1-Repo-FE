export interface UserDto {
  id?: number;
  name?: string;
}
